/*
Cleanup on Django 1.8

Since Django 1.9 all functionality moved to admin/RelatedObjectLookups.js 
*/